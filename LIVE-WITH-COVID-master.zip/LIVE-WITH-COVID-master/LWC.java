/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lwc;

/**
 *
 * @author User
 */
public class LWC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new logas().setVisible(true);
    }
    
}
