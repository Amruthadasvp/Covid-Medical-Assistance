# LIVE-WITH-COVID
Covid Medical Assistance Application

This is a project intiated by our team when a pandemic called Covid-19 spread through out the world. Live-With-covid application can be used for the easy contact less communication between the health sector professionals and high risk category people. Looking forward for the further development of our application.
